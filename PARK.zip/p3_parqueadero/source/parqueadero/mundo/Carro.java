package parqueadero.mundo;

public class Carro {

}
